"""Smart FAQ Chatbot - Flask backend (SQLite storage + TF-IDF/cosine NLP matching)."""
import json
import os
import sqlite3
import uuid
from datetime import datetime

from flask import Flask, g, jsonify, render_template, request, session

from nlp.preprocessing import preprocess
from nlp.similarity import FAQMatcher

BASE = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(BASE, "database", "faq_database.db")
SEED_PATH = os.path.join(BASE, "data", "faqs.json")
NO_MATCH = "I'm sorry, I couldn't find a suitable answer. Please try asking in a different way."
CATEGORIES = [
    "General Questions", "Account and Registration", "Products and Services",
    "Payments and Billing", "Technical Support", "Privacy and Security",
]
MAX_QUESTION_LEN = 500

app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", "dev-secret-change-me")
matcher = FAQMatcher()


# ---------------------------------------------------------------- database
def get_db():
    if "db" not in g:
        g.db = sqlite3.connect(DB_PATH)
        g.db.row_factory = sqlite3.Row
    return g.db


@app.teardown_appcontext
def close_db(_):
    db = g.pop("db", None)
    if db:
        db.close()


def init_db():
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    db = sqlite3.connect(DB_PATH)
    db.executescript("""
        CREATE TABLE IF NOT EXISTS faqs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            category TEXT NOT NULL,
            question TEXT NOT NULL,
            answer TEXT NOT NULL,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS chat_history (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            session_id TEXT NOT NULL,
            question TEXT NOT NULL,
            answer TEXT NOT NULL,
            score REAL NOT NULL,
            matched INTEGER NOT NULL,
            faq_id INTEGER,
            created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS query_log (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            matched INTEGER NOT NULL,
            created_at TEXT NOT NULL
        );
    """)
    if db.execute("SELECT COUNT(*) FROM faqs").fetchone()[0] == 0 and os.path.exists(SEED_PATH):
        with open(SEED_PATH, encoding="utf-8") as f:
            for item in json.load(f):
                db.execute("INSERT INTO faqs (category, question, answer) VALUES (?,?,?)",
                           (item["category"], item["question"], item["answer"]))
    db.commit()
    db.close()


def all_faqs(db=None):
    db = db or get_db()
    return [dict(r) for r in db.execute("SELECT id, category, question, answer FROM faqs ORDER BY id")]


def rebuild_model():
    db = sqlite3.connect(DB_PATH)
    db.row_factory = sqlite3.Row
    matcher.fit([dict(r) for r in db.execute("SELECT id, category, question, answer FROM faqs")])
    db.close()


def now():
    return datetime.now().isoformat(timespec="seconds")


def err(message, code=400):
    return jsonify({"error": message}), code


def validate_faq(data):
    """Return (clean_dict, error_message)."""
    if not isinstance(data, dict):
        return None, "Request body must be JSON."
    category = str(data.get("category", "")).strip()
    question = str(data.get("question", "")).strip()
    answer = str(data.get("answer", "")).strip()
    if category not in CATEGORIES:
        return None, "Please choose a valid category."
    if len(question) < 5 or len(question) > MAX_QUESTION_LEN:
        return None, "Question must be between 5 and 500 characters."
    if len(answer) < 5 or len(answer) > 2000:
        return None, "Answer must be between 5 and 2000 characters."
    return {"category": category, "question": question, "answer": answer}, None


def is_duplicate(db, question, ignore_id=None):
    key = preprocess(question) or question.lower()
    for r in db.execute("SELECT id, question FROM faqs"):
        if r["id"] != ignore_id and (preprocess(r["question"]) or r["question"].lower()) == key:
            return True
    return False


def sid():
    if "sid" not in session:
        session["sid"] = uuid.uuid4().hex
    return session["sid"]


# ------------------------------------------------------------------- pages
@app.route("/")
def index():
    return render_template("index.html")


@app.route("/chatbot")
def chatbot_page():
    return render_template("chatbot.html")


@app.route("/admin")
def admin_page():
    return render_template("admin.html")


# --------------------------------------------------------------------- API
@app.get("/api/categories")
def api_categories():
    counts = {r["category"]: r["n"] for r in get_db().execute(
        "SELECT category, COUNT(*) n FROM faqs GROUP BY category")}
    return jsonify([{"name": c, "count": counts.get(c, 0)} for c in CATEGORIES])


@app.get("/api/faqs")
def api_faqs():
    faqs = all_faqs()
    cat = request.args.get("category", "").strip()
    q = request.args.get("search", "").strip().lower()
    if cat:
        faqs = [f for f in faqs if f["category"] == cat]
    if q:
        faqs = [f for f in faqs if q in f["question"].lower() or q in f["answer"].lower()]
    return jsonify(faqs)


@app.post("/api/faqs")
def api_add_faq():
    data, msg = validate_faq(request.get_json(silent=True))
    if msg:
        return err(msg)
    db = get_db()
    if is_duplicate(db, data["question"]):
        return err("A similar FAQ question already exists.", 409)
    cur = db.execute("INSERT INTO faqs (category, question, answer) VALUES (?,?,?)",
                     (data["category"], data["question"], data["answer"]))
    db.commit()
    rebuild_model()
    return jsonify({"id": cur.lastrowid, **data}), 201


@app.put("/api/faqs/<int:faq_id>")
def api_update_faq(faq_id):
    data, msg = validate_faq(request.get_json(silent=True))
    if msg:
        return err(msg)
    db = get_db()
    if not db.execute("SELECT 1 FROM faqs WHERE id=?", (faq_id,)).fetchone():
        return err("FAQ not found.", 404)
    if is_duplicate(db, data["question"], ignore_id=faq_id):
        return err("A similar FAQ question already exists.", 409)
    db.execute("UPDATE faqs SET category=?, question=?, answer=? WHERE id=?",
               (data["category"], data["question"], data["answer"], faq_id))
    db.commit()
    rebuild_model()
    return jsonify({"id": faq_id, **data})


@app.delete("/api/faqs/<int:faq_id>")
def api_delete_faq(faq_id):
    db = get_db()
    cur = db.execute("DELETE FROM faqs WHERE id=?", (faq_id,))
    db.commit()
    if cur.rowcount == 0:
        return err("FAQ not found.", 404)
    rebuild_model()
    return jsonify({"deleted": faq_id})


@app.post("/api/chat")
def api_chat():
    body = request.get_json(silent=True)
    question = str(body.get("question", "")).strip() if isinstance(body, dict) else ""
    if not question:
        return err("Please type a question before sending.")
    if len(question) > MAX_QUESTION_LEN:
        return err(f"Question is too long (max {MAX_QUESTION_LEN} characters).")

    result = matcher.match(question)
    matched = bool(result["matched"])
    answer = result["faq"]["answer"] if matched else NO_MATCH
    faq = result["faq"] if matched else None
    ts = now()
    db = get_db()
    db.execute("INSERT INTO chat_history (session_id, question, answer, score, matched, faq_id, created_at) "
               "VALUES (?,?,?,?,?,?,?)",
               (sid(), question, answer, result["score"], int(matched), faq["id"] if faq else None, ts))
    db.execute("INSERT INTO query_log (matched, created_at) VALUES (?,?)", (int(matched), ts))
    db.commit()
    return jsonify({
        "answer": answer,
        "matched": matched,
        "score": result["score"],
        "matched_question": faq["question"] if faq else None,
        "category": faq["category"] if faq else None,
        "alternatives": result["alternatives"] if not matched or result["score"] < 0.6 else [],
        "timestamp": ts,
    })


@app.get("/api/history")
def api_history():
    rows = get_db().execute(
        "SELECT id, question, answer, score, matched, created_at FROM chat_history "
        "WHERE session_id=? ORDER BY id", (sid(),)).fetchall()
    return jsonify([dict(r) for r in rows])


@app.delete("/api/history")
def api_clear_history():
    db = get_db()
    db.execute("DELETE FROM chat_history WHERE session_id=?", (sid(),))
    db.commit()
    return jsonify({"cleared": True})


@app.get("/api/stats")
def api_stats():
    db = get_db()
    total_faqs = db.execute("SELECT COUNT(*) FROM faqs").fetchone()[0]
    total_q = db.execute("SELECT COUNT(*) FROM query_log").fetchone()[0]
    matched = db.execute("SELECT COUNT(*) FROM query_log WHERE matched=1").fetchone()[0]
    return jsonify({"total_faqs": total_faqs, "total_questions": total_q,
                    "matched": matched, "unmatched": total_q - matched,
                    "categories": len(CATEGORIES)})


@app.errorhandler(404)
def not_found(e):
    if request.path.startswith("/api/"):
        return err("Endpoint not found.", 404)
    return render_template("index.html"), 404


@app.errorhandler(500)
def server_error(e):
    return err("Internal server error.", 500)


init_db()
rebuild_model()

if __name__ == "__main__":
    app.run(debug=True, port=5000)
