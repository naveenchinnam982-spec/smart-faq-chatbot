"""TF-IDF + cosine similarity FAQ matcher (with light spelling correction)."""
import difflib
import threading
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
from .preprocessing import preprocess, clean_text, tokenize

THRESHOLD = 0.30  # minimum blended score to accept an answer


class FAQMatcher:
    def __init__(self, threshold: float = THRESHOLD):
        self.threshold = threshold
        self._lock = threading.Lock()
        self.faqs = []

    def fit(self, faqs):
        """(Re)build the TF-IDF models from a list of FAQ dicts."""
        with self._lock:
            self.faqs = list(faqs)
            if not self.faqs:
                self.q_matrix = None
                return
            q_docs = [preprocess(f["question"]) for f in self.faqs]
            qa_docs = [preprocess(f["question"] + " " + f["answer"]) for f in self.faqs]
            self.word_vec = TfidfVectorizer(ngram_range=(1, 2), sublinear_tf=True)
            self.char_vec = TfidfVectorizer(analyzer="char_wb", ngram_range=(3, 5), sublinear_tf=True)
            self.qa_vec = TfidfVectorizer(sublinear_tf=True)
            self.q_matrix = self.word_vec.fit_transform(q_docs)
            self.c_matrix = self.char_vec.fit_transform(q_docs)
            self.qa_matrix = self.qa_vec.fit_transform(qa_docs)
            self.vocab = list(self.qa_vec.vocabulary_.keys())

    def _correct_spelling(self, processed: str) -> str:
        """Replace unknown tokens by the closest vocabulary word (handles typos)."""
        out = []
        for tok in processed.split():
            if tok in self.qa_vec.vocabulary_ or len(tok) < 4:
                out.append(tok)
            else:
                close = difflib.get_close_matches(tok, self.vocab, n=1, cutoff=0.8)
                out.append(close[0] if close else tok)
        return " ".join(out)

    def match(self, question: str, top_k: int = 3):
        """Return dict with best FAQ, score and alternatives."""
        with self._lock:
            if not self.faqs or self.q_matrix is None:
                return {"matched": False, "score": 0.0, "faq": None, "alternatives": []}
            processed = self._correct_spelling(preprocess(question))
            if not processed:
                return {"matched": False, "score": 0.0, "faq": None, "alternatives": []}
            w = cosine_similarity(self.word_vec.transform([processed]), self.q_matrix)[0]
            c = cosine_similarity(self.char_vec.transform([processed]), self.c_matrix)[0]
            a = cosine_similarity(self.qa_vec.transform([processed]), self.qa_matrix)[0]
            scores = 0.45 * w + 0.25 * c + 0.30 * a
            order = np.argsort(scores)[::-1]
            best = int(order[0])
            best_score = float(scores[best])
            alts = [
                {"id": self.faqs[i]["id"], "question": self.faqs[i]["question"], "score": round(float(scores[i]), 3)}
                for i in order[1:top_k + 1] if scores[i] > 0.15
            ]
            return {
                "matched": best_score >= self.threshold,
                "score": round(best_score, 4),
                "faq": self.faqs[best],
                "alternatives": alts,
                "processed": processed,
            }
