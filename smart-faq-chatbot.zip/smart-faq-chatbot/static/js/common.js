// Shared helpers: theme toggle, mobile menu, toast, fetch wrapper.
(function () {
  const root = document.documentElement;
  const toggle = document.getElementById('themeToggle');
  function paint() {
    toggle.innerHTML = root.getAttribute('data-theme') === 'dark'
      ? '<i class="bi bi-sun-fill"></i>' : '<i class="bi bi-moon-stars-fill"></i>';
  }
  toggle.addEventListener('click', () => {
    const next = root.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
    root.setAttribute('data-theme', next);
    try { localStorage.setItem('theme', next); } catch (e) {}
    paint();
  });
  paint();
  document.getElementById('menuBtn').addEventListener('click', () =>
    document.getElementById('navLinks').classList.toggle('open'));
})();

function toast(message, type) {
  const el = document.createElement('div');
  el.className = 'toast' + (type === 'error' ? ' error' : '');
  el.textContent = message;
  document.getElementById('toasts').appendChild(el);
  setTimeout(() => el.remove(), 3200);
}

async function api(url, options) {
  const opts = Object.assign({ headers: { 'Content-Type': 'application/json' } }, options || {});
  if (opts.body && typeof opts.body !== 'string') opts.body = JSON.stringify(opts.body);
  let res;
  try { res = await fetch(url, opts); }
  catch (e) { throw new Error('Cannot reach the server. Check that Flask is running.'); }
  let data = null;
  try { data = await res.json(); } catch (e) {}
  if (!res.ok) throw new Error((data && data.error) || 'Request failed (' + res.status + ').');
  return data;
}
