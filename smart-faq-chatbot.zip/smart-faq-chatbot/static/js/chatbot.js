const $ = (id) => document.getElementById(id);
const messagesEl = $('messages'), input = $('msgInput'), sendBtn = $('sendBtn'), errEl = $('inputError');
const WELCOME = "Hi! I'm the Smart FAQ Bot. Ask me about accounts, billing, products, technical problems, or privacy, and I'll find the best answer.";
let faqs = [], busy = false, activeCat = '';

function fmtTime(iso) {
  const d = iso ? new Date(iso) : new Date();
  return d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
}
function scrollDown() { messagesEl.scrollTop = messagesEl.scrollHeight; }

function addMessage(role, text, opts) {
  opts = opts || {};
  const wrap = document.createElement('div');
  wrap.className = 'msg ' + role + (opts.error ? ' error' : '');
  const av = document.createElement('div');
  av.className = 'avatar';
  av.innerHTML = role === 'bot' ? '<i class="bi bi-robot"></i>' : '<i class="bi bi-person-fill"></i>';
  const col = document.createElement('div');
  const bubble = document.createElement('div');
  bubble.className = 'bubble';
  if (opts.matchedQuestion) {
    const mq = document.createElement('div');
    mq.className = 'match-q';
    mq.textContent = 'Matched FAQ: ' + opts.matchedQuestion;
    bubble.appendChild(mq);
  }
  const body = document.createElement('div');
  body.textContent = text;
  bubble.appendChild(body);
  if (opts.alternatives && opts.alternatives.length) {
    const alts = document.createElement('div');
    alts.className = 'alts';
    opts.alternatives.forEach((a) => {
      const b = document.createElement('button');
      b.className = 'alt'; b.textContent = a.question;
      b.addEventListener('click', () => ask(a.question));
      alts.appendChild(b);
    });
    bubble.appendChild(alts);
  }
  const meta = document.createElement('div');
  meta.className = 'meta';
  const t = document.createElement('span');
  t.textContent = fmtTime(opts.time);
  meta.appendChild(t);
  if (typeof opts.score === 'number') {
    const s = document.createElement('span');
    s.className = 'score-pill' + (opts.matched ? '' : ' low');
    s.textContent = 'Similarity ' + opts.score.toFixed(2);
    meta.appendChild(s);
  }
  col.appendChild(bubble); col.appendChild(meta);
  wrap.appendChild(av); wrap.appendChild(col);
  messagesEl.appendChild(wrap);
  scrollDown();
}

function showTyping() {
  const el = document.createElement('div');
  el.className = 'msg bot typing'; el.id = 'typing';
  el.innerHTML = '<div class="avatar"><i class="bi bi-robot"></i></div><div class="bubble" aria-label="Bot is typing"><span></span><span></span><span></span></div>';
  messagesEl.appendChild(el); scrollDown();
}
function hideTyping() { const t = $('typing'); if (t) t.remove(); }

function setError(msg) {
  errEl.textContent = msg || '';
  errEl.classList.toggle('show', !!msg);
}

async function ask(text) {
  if (busy) return;
  text = (text || '').trim();
  if (!text) { setError('Please type a question before sending.'); input.focus(); return; }
  setError('');
  busy = true; sendBtn.disabled = true;
  addMessage('user', text);
  input.value = '';
  showTyping();
  try {
    const [res] = await Promise.all([
      api('/api/chat', { method: 'POST', body: { question: text } }),
      new Promise((r) => setTimeout(r, 600)),   // keeps the typing animation visible
    ]);
    hideTyping();
    addMessage('bot', res.answer, {
      time: res.timestamp, score: res.score, matched: res.matched,
      matchedQuestion: res.matched ? res.matched_question : null,
      alternatives: res.alternatives,
    });
  } catch (e) {
    hideTyping();
    addMessage('bot', e.message, { error: true });
  } finally {
    busy = false; sendBtn.disabled = false; input.focus();
  }
}

function renderSuggestions() {
  const pool = faqs.filter((f) => !activeCat || f.category === activeCat);
  const picks = pool.slice(0, 6);
  const list = $('suggestList'), mob = $('mobileSuggest');
  list.innerHTML = ''; mob.innerHTML = '';
  picks.forEach((f) => {
    const b = document.createElement('button');
    b.className = 'suggest'; b.textContent = f.question;
    b.addEventListener('click', () => ask(f.question));
    list.appendChild(b);
    const m = document.createElement('button');
    m.className = 'alt'; m.textContent = f.question;
    m.addEventListener('click', () => ask(f.question));
    mob.appendChild(m);
  });
}

async function loadSidebar() {
  const [cats, all] = await Promise.all([api('/api/categories'), api('/api/faqs')]);
  faqs = all;
  const list = $('catList');
  list.innerHTML = '';
  [{ name: '', label: 'All categories', count: all.length }].concat(
    cats.map((c) => ({ name: c.name, label: c.name, count: c.count }))
  ).forEach((c) => {
    const b = document.createElement('button');
    b.className = 'cat-btn' + (c.name === activeCat ? ' active' : '');
    const l = document.createElement('span'); l.textContent = c.label;
    const n = document.createElement('span'); n.className = 'count'; n.textContent = c.count;
    b.appendChild(l); b.appendChild(n);
    b.addEventListener('click', () => { activeCat = c.name; loadSidebar(); });
    list.appendChild(b);
  });
  renderSuggestions();
}

async function loadHistory() {
  messagesEl.innerHTML = '';
  addMessage('bot', WELCOME);
  try {
    const rows = await api('/api/history');
    if (rows.length) {
      const d = document.createElement('div');
      d.className = 'day-divider'; d.textContent = 'Previous conversation';
      messagesEl.appendChild(d);
      rows.forEach((r) => {
        addMessage('user', r.question, { time: r.created_at });
        addMessage('bot', r.answer, { time: r.created_at, score: r.score, matched: !!r.matched });
      });
    }
  } catch (e) { addMessage('bot', e.message, { error: true }); }
}

$('clearBtn').addEventListener('click', async () => {
  if (!confirm('Clear the whole conversation and saved history?')) return;
  try {
    await api('/api/history', { method: 'DELETE' });
    await loadHistory();
    toast('Chat history cleared');
  } catch (e) { toast(e.message, 'error'); }
});
sendBtn.addEventListener('click', () => ask(input.value));
input.addEventListener('keydown', (e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); ask(input.value); } });
input.addEventListener('input', () => setError(''));

loadHistory();
loadSidebar().catch((e) => toast(e.message, 'error'));
input.focus();
