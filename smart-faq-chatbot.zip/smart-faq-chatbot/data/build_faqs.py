"""One-off helper that generates data/faqs.json (seed dataset)."""
import json, os

D = {
"General Questions": [
("What is Nimbus?", "Nimbus is a cloud workspace that brings tasks, documents and team chat together in one place so teams can plan and ship work faster."),
("Who can use Nimbus?", "Nimbus is built for individuals, students, small teams and large companies. Anyone aged 16 or older can create an account."),
("In which languages is Nimbus available?", "Nimbus is available in English, Spanish, French, German, Hindi and Portuguese. You can change the language under Settings > Preferences."),
("What are your customer support hours?", "Our support team is available Monday to Friday, 9 AM to 6 PM (UTC). Premium customers get 24/7 priority support."),
("How can I contact customer support?", "You can reach us through the in-app chat, by email at support@nimbus.example, or by phone on 1-800-555-0199 during support hours."),
("Is there a mobile app for Nimbus?", "Yes. Nimbus apps are available for iOS and Android. Search for 'Nimbus' in the App Store or Google Play and sign in with your account."),
("Does Nimbus work offline?", "The mobile and desktop apps let you view and edit recently opened items offline. Changes sync automatically when you reconnect to the internet."),
("Where is the company located?", "Nimbus Labs is headquartered in Austin, Texas, with remote teams across Europe and Asia."),
("How do I send feedback or suggest a feature?", "Open the Help menu and choose 'Send feedback', or post your idea in our community forum. Product managers review every submission."),
("Do you offer a free trial?", "Yes. Every new account gets a 14-day free trial of the Pro plan with no credit card required."),
],
"Account and Registration": [
("How do I create an account?", "Click 'Sign up' on the home page, enter your name, email and a password, then confirm your email address using the link we send you."),
("I forgot my password. How can I reset it?", "Click 'Forgot password' on the login page, enter your registered email, and follow the reset link we send. The link expires after 30 minutes."),
("How do I change my email address?", "Go to Settings > Account > Email, enter your new address and confirm it with the verification code sent to the new inbox."),
("How do I update my profile information?", "Open your profile picture menu, choose 'Profile', then edit your name, photo, job title or time zone and click Save."),
("Why have I not received the verification email?", "Check your spam or junk folder first. If it is not there, click 'Resend verification email' on the login page. Make sure you typed your address correctly."),
("Can I sign up using Google or Microsoft?", "Yes. Choose 'Continue with Google' or 'Continue with Microsoft' on the sign up page to register without creating a new password."),
("How do I delete my account?", "Go to Settings > Account > Delete account. Your data is permanently removed after a 30-day grace period during which you can still restore it."),
("Can I have multiple accounts with one email?", "No. Each email address can be linked to only one Nimbus account. You can use plus addressing (name+work@example.com) for a second account."),
("How do I enable two-factor authentication?", "Open Settings > Security > Two-factor authentication, scan the QR code with an authenticator app and enter the 6-digit code to finish setup."),
("My account has been locked. What should I do?", "Accounts lock after five failed login attempts. Wait 15 minutes and try again, or use 'Forgot password' to unlock it immediately."),
],
"Products and Services": [
("What plans does Nimbus offer?", "We offer Free, Pro and Enterprise plans. Free covers personal use, Pro adds unlimited projects and automation, and Enterprise adds single sign-on and advanced admin controls."),
("What is the difference between Pro and Enterprise?", "Pro is designed for teams up to 50 people. Enterprise adds SSO, audit logs, custom roles, a dedicated account manager and a 99.99% uptime guarantee."),
("How much storage do I get?", "Free accounts include 5 GB, Pro accounts include 1 TB per user, and Enterprise plans offer unlimited storage."),
("Can I integrate Nimbus with other tools?", "Yes. Nimbus integrates with Slack, Google Drive, GitHub, Jira, Zoom and over 100 other apps. Browse them under Settings > Integrations."),
("Do you provide an API for developers?", "Yes. Our REST API lets you manage projects, tasks and users programmatically. Generate an API key under Settings > Developer and read the docs at developers.nimbus.example."),
("How do I invite team members?", "Open Team > Members, click 'Invite', and enter their email addresses. They will receive a link to join your workspace."),
("Can I upgrade or downgrade my plan?", "Yes. Go to Settings > Billing > Change plan at any time. Upgrades apply immediately, and downgrades take effect at the end of the billing cycle."),
("Do you offer discounts for students or nonprofits?", "Yes. Verified students and registered nonprofits receive 50% off Pro plans. Apply through the Education and Nonprofit page with proof of eligibility."),
("What file types can I upload?", "You can upload documents, spreadsheets, images, videos, PDFs and ZIP archives. The maximum size per file is 2 GB on Pro and 250 MB on Free."),
("Can I export my data from Nimbus?", "Yes. Use Settings > Data > Export to download all your projects, tasks and files in CSV, JSON or ZIP format."),
],
"Payments and Billing": [
("What payment methods do you accept?", "We accept Visa, Mastercard, American Express, PayPal, Apple Pay, Google Pay and bank transfers for annual Enterprise plans."),
("How do I update my credit card details?", "Go to Settings > Billing > Payment method, click 'Update card' and enter the new details. The change applies to your next invoice."),
("How can I download my invoice?", "Open Settings > Billing > Invoices and click the download icon next to any invoice to get a PDF copy."),
("Can I get a refund?", "We offer a full refund within 30 days of your first purchase. After that, refunds are reviewed case by case by our billing team."),
("Why was my payment declined?", "Payments are usually declined because of insufficient funds, an expired card, or a bank security check. Contact your bank or try a different payment method."),
("How do I cancel my subscription?", "Go to Settings > Billing > Cancel subscription. You keep access until the end of the current billing period and will not be charged again."),
("Will I be charged automatically every month?", "Yes. Paid plans renew automatically at the end of each billing cycle. We email you a reminder 7 days before every renewal."),
("Do you charge sales tax or VAT?", "Yes. Taxes are added at checkout based on your billing country. Businesses can enter a VAT or GST number to apply exemptions where applicable."),
("Is there a discount for annual billing?", "Yes. Paying yearly saves you 20% compared with monthly billing. Switch under Settings > Billing > Billing cycle."),
("I was charged twice. What should I do?", "Duplicate charges are usually temporary authorization holds that disappear in 3 to 5 days. If both remain, email billing@nimbus.example with your invoice number for a refund."),
],
"Technical Support": [
("The website is not loading. What should I do?", "Refresh the page, clear your browser cache and check your internet connection. You can also check status.nimbus.example for any ongoing outages."),
("Which browsers are supported?", "Nimbus works on the latest versions of Chrome, Firefox, Safari and Edge. Internet Explorer is not supported."),
("How do I report a bug?", "Open Help > Report a problem, describe what happened and attach a screenshot. Our engineers respond within one business day."),
("Why are my files not syncing?", "Check that you are online and have enough storage. Then sign out and back in, or click the sync icon in the app to force a refresh."),
("How do I clear the cache and cookies?", "In your browser settings, open Privacy and choose 'Clear browsing data', select cached images and cookies, then reload Nimbus."),
("The mobile app keeps crashing. How can I fix it?", "Update the app to the latest version, restart your phone and make sure you have free storage. If it still crashes, reinstall the app and sign in again."),
("How do I enable notifications?", "Go to Settings > Notifications and turn on email, push or desktop alerts. Also allow notifications for Nimbus in your device or browser settings."),
("Why is Nimbus running slowly?", "Slow performance is often caused by many open tabs, an outdated browser or a weak connection. Try closing other tabs, updating your browser and restarting your router."),
("How do I install the desktop app?", "Download the installer for Windows, macOS or Linux from the Downloads page, open it and follow the on-screen instructions."),
("How do I restore a deleted file?", "Deleted items stay in the Trash for 30 days. Open Trash, select the item and click 'Restore' to put it back in its original location."),
],
"Privacy and Security": [
("How does Nimbus protect my data?", "All data is encrypted in transit with TLS 1.3 and at rest with AES-256. We also run regular third-party security audits and penetration tests."),
("Do you sell my personal information?", "No. We never sell your personal data to advertisers or third parties. Data is only shared with service providers who help us run Nimbus."),
("Is Nimbus GDPR compliant?", "Yes. Nimbus complies with GDPR and CCPA. You can access, correct, export or delete your personal data at any time from Settings > Privacy."),
("Where is my data stored?", "Data is stored in secure data centers in the United States and the European Union. Enterprise customers can choose their preferred region."),
("How can I see which devices are logged in?", "Open Settings > Security > Active sessions to see every device and location. Click 'Sign out' next to any session you do not recognize."),
("What should I do if I think my account was hacked?", "Change your password immediately, enable two-factor authentication and sign out of all devices. Then contact security@nimbus.example so we can investigate."),
("How do I know an email from Nimbus is genuine?", "Real emails come from the nimbus.example domain and never ask for your password. If you are unsure, do not click links and report the message to security@nimbus.example."),
("Who can see my files and projects?", "Only people you explicitly share them with. You can review and change sharing permissions at any time from the Share button on each item."),
("Do you use cookies?", "We use essential cookies to keep you signed in and optional analytics cookies to improve Nimbus. You can manage your choices in Settings > Privacy > Cookies."),
("How long do you keep my data after I leave?", "After account deletion we remove your data within 30 days, except for billing records that the law requires us to keep for up to 7 years."),
],
}

out, i = [], 1
for cat, rows in D.items():
    for q, a in rows:
        out.append({"id": i, "category": cat, "question": q, "answer": a})
        i += 1

here = os.path.dirname(os.path.abspath(__file__))
with open(os.path.join(here, "faqs.json"), "w", encoding="utf-8") as f:
    json.dump(out, f, indent=2, ensure_ascii=False)
print(len(out), "faqs written")
