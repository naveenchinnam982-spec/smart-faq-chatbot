# Smart FAQ Chatbot Using NLP

An FAQ chatbot website built with **Python Flask**, **NLTK** and **scikit-learn**. Users ask questions in natural language and the app returns the most relevant answer from an FAQ dataset using **TF-IDF vectors and cosine similarity**.

## Objectives
- Collect FAQs for a topic or product (a fictional cloud workspace called *Nimbus*).
- Preprocess text with NLP techniques.
- Match user questions with the most similar FAQ.
- Show the best answer in an interactive chat interface.
- Let an administrator manage the FAQ dataset.

## Features
- Home page with hero, features and how-it-works sections
- Chat interface: welcome message, typing animation, timestamps, similarity score, suggested questions, auto-scroll, Enter key support, empty-message validation, clear chat
- 60 FAQs across 6 categories (10 each)
- Typo tolerance (character n-grams + vocabulary spelling correction) and synonym normalisation
- Admin dashboard: statistics, add / edit / delete FAQ, search, filter by category, duplicate prevention
- Persistent storage in SQLite (FAQs and chat history); the model is retrained automatically after every FAQ change
- Light and dark mode, responsive layout (desktop, tablet, mobile)

## Technologies
| Layer | Tools |
|---|---|
| Frontend | HTML5, CSS3, vanilla JavaScript, Bootstrap Icons, Google Fonts |
| Backend | Python 3.9+, Flask |
| NLP | NLTK (tokenizer, stopwords, Porter stemmer), scikit-learn (TfidfVectorizer, cosine_similarity) |
| Database | SQLite (seeded from `data/faqs.json`) |

## NLP workflow
1. Receive the user's question.
2. Lowercase and remove punctuation / special characters.
3. Normalise common phrases (e.g. "money back" becomes "refund", "sign up" becomes "create account").
4. Tokenize (`nltk.tokenize.wordpunct_tokenize`).
5. Remove stopwords (NLTK list if available, otherwise scikit-learn's list).
6. Stem tokens with `PorterStemmer`.
7. Correct likely typos by mapping unknown words to the closest vocabulary word (`difflib`).
8. Convert FAQs to TF-IDF vectors (word 1-2 grams on questions, character 3-5 grams on questions, word unigrams on question + answer).
9. Compute cosine similarity between the user vector and every FAQ vector.
10. Blend the three scores: `0.45 * word + 0.25 * char + 0.30 * question+answer`.
11. If the best score is at least **0.30**, return that FAQ's answer. Otherwise return:
    *"I'm sorry, I couldn't find a suitable answer. Please try asking in a different way."*

The threshold is set in `nlp/similarity.py` (`THRESHOLD`).

## Project structure
```
smart-faq-chatbot/
├── app.py                     Flask app, routes, SQLite access, validation
├── requirements.txt
├── README.md
├── database/faq_database.db   (created on first run)
├── data/
│   ├── faqs.json              Seed dataset (60 FAQs)
│   └── build_faqs.py          Script that regenerates faqs.json
├── nlp/
│   ├── preprocessing.py       Cleaning, tokenizing, stopwords, stemming
│   └── similarity.py          TF-IDF + cosine similarity matcher
├── templates/                 base.html, index.html, chatbot.html, admin.html
└── static/
    ├── css/style.css
    ├── js/                    common.js, chatbot.js, admin.js
    └── images/
```

## Installation
```bash
cd smart-faq-chatbot
python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt
```
Optional: `python -c "import nltk; nltk.download('stopwords')"` to use NLTK's own stopword list. The app works without it.

## Run
```bash
python app.py
```
Open http://127.0.0.1:5000 (chatbot at `/chatbot`, admin at `/admin`). The database is created and seeded automatically on first start. Delete `database/faq_database.db` to reset to the seed data.

Fonts and icons load from CDNs, so an internet connection gives the intended look. The app still works without them.

## API
| Method | Endpoint | Description |
|---|---|---|
| GET | `/api/faqs?search=&category=` | List FAQs, optionally filtered |
| POST | `/api/faqs` | Create FAQ `{category, question, answer}` (409 on duplicate) |
| PUT | `/api/faqs/<id>` | Update FAQ |
| DELETE | `/api/faqs/<id>` | Delete FAQ |
| GET | `/api/categories` | Categories with FAQ counts |
| POST | `/api/chat` | `{question}` returns `{answer, matched, score, matched_question, category, alternatives, timestamp}` |
| GET | `/api/history` | Chat history of the current browser session |
| DELETE | `/api/history` | Clear that history |
| GET | `/api/stats` | `{total_faqs, total_questions, matched, unmatched}` |

Errors return JSON `{"error": "..."}` with status 400, 404 or 409.

## Example questions
| User question | Matched FAQ | Score |
|---|---|---|
| How do I create an account? | How do I create an account? | 0.85 |
| how can i sign up | How do I create an account? | 0.85 |
| I forgt my pasword | I forgot my password. How can I reset it? | 0.72 |
| can I get my money back | Can I get a refund? | 0.88 |
| is my data encrypted | How does Nimbus protect my data? | 0.68 |
| what is the capital of France | (no match, fallback message) | 0.03 |

## Testing performed
Exact match, paraphrase, spelling errors, unrelated question, add / edit / delete FAQ, duplicate rejection, empty message, clear history, search and category filter, plus desktop (1366px) and mobile (390px) layouts, in a headless browser with no unexpected JavaScript errors.

## Screenshots
- `static/images/home.png`
- `static/images/chatbot.png`
- `static/images/admin.png`
