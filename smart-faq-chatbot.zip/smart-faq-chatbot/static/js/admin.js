const $ = (id) => document.getElementById(id);
let faqs = [], editingId = null, deletingId = null, timer = null;

async function loadStats() {
  try {
    const s = await api('/api/stats');
    $('stFaqs').textContent = s.total_faqs; $('stQ').textContent = s.total_questions;
    $('stM').textContent = s.matched; $('stU').textContent = s.unmatched;
  } catch (e) { toast(e.message, 'error'); }
}

async function loadCategories() {
  const cats = await api('/api/categories');
  [$('filterCat'), $('fCat')].forEach((sel, i) => {
    const keep = sel.value;
    sel.innerHTML = i === 0 ? '<option value="">All categories</option>' : '';
    cats.forEach((c) => { const o = document.createElement('option'); o.value = c.name; o.textContent = c.name; sel.appendChild(o); });
    sel.value = keep;
  });
}

async function loadFaqs() {
  const p = new URLSearchParams();
  if ($('search').value.trim()) p.set('search', $('search').value.trim());
  if ($('filterCat').value) p.set('category', $('filterCat').value);
  try { faqs = await api('/api/faqs?' + p.toString()); render(); }
  catch (e) { toast(e.message, 'error'); }
}

function render() {
  const body = $('faqBody');
  body.innerHTML = '';
  $('emptyMsg').style.display = faqs.length ? 'none' : 'block';
  faqs.forEach((f) => {
    const tr = document.createElement('tr');
    const cells = [['', f.id], ['', null], ['q', f.question], ['a', f.answer], ['', null]];
    cells.forEach(([cls, text], i) => {
      const td = document.createElement('td');
      if (cls) td.className = cls;
      if (i === 1) { const t = document.createElement('span'); t.className = 'tag'; t.textContent = f.category; td.appendChild(t); }
      else if (i === 4) {
        const box = document.createElement('div'); box.className = 'row-actions';
        const e = document.createElement('button'); e.className = 'btn btn-ghost btn-sm'; e.innerHTML = '<i class="bi bi-pencil"></i> Edit';
        e.addEventListener('click', () => openForm(f));
        const d = document.createElement('button'); d.className = 'btn btn-ghost btn-sm'; d.innerHTML = '<i class="bi bi-trash3"></i> Delete';
        d.addEventListener('click', () => openDelete(f));
        box.appendChild(e); box.appendChild(d); td.appendChild(box);
      } else td.textContent = text;
      tr.appendChild(td);
    });
    body.appendChild(tr);
  });
}

function openForm(f) {
  editingId = f ? f.id : null;
  $('modalTitle').textContent = f ? 'Edit FAQ' : 'Add FAQ';
  $('fCat').value = f ? f.category : $('fCat').options[0].value;
  $('fQ').value = f ? f.question : ''; $('fA').value = f ? f.answer : '';
  $('formError').textContent = '';
  $('modalBg').classList.add('show'); $('fQ').focus();
}
function closeForm() { $('modalBg').classList.remove('show'); }

async function saveFaq() {
  const body = { category: $('fCat').value, question: $('fQ').value.trim(), answer: $('fA').value.trim() };
  if (body.question.length < 5) { $('formError').textContent = 'Question must be at least 5 characters.'; return; }
  if (body.answer.length < 5) { $('formError').textContent = 'Answer must be at least 5 characters.'; return; }
  $('saveBtn').disabled = true;
  try {
    await api(editingId ? '/api/faqs/' + editingId : '/api/faqs', { method: editingId ? 'PUT' : 'POST', body });
    closeForm(); toast(editingId ? 'FAQ updated' : 'FAQ added');
    await Promise.all([loadFaqs(), loadStats(), loadCategories()]);
  } catch (e) { $('formError').textContent = e.message; }
  finally { $('saveBtn').disabled = false; }
}

function openDelete(f) { deletingId = f.id; $('delText').textContent = '"' + f.question + '" will be removed permanently.'; $('delBg').classList.add('show'); }
async function confirmDelete() {
  try {
    await api('/api/faqs/' + deletingId, { method: 'DELETE' });
    $('delBg').classList.remove('show'); toast('FAQ deleted');
    await Promise.all([loadFaqs(), loadStats()]);
  } catch (e) { toast(e.message, 'error'); }
}

$('addBtn').addEventListener('click', () => openForm(null));
$('cancelBtn').addEventListener('click', closeForm);
$('saveBtn').addEventListener('click', saveFaq);
$('delCancel').addEventListener('click', () => $('delBg').classList.remove('show'));
$('delConfirm').addEventListener('click', confirmDelete);
$('filterCat').addEventListener('change', loadFaqs);
$('search').addEventListener('input', () => { clearTimeout(timer); timer = setTimeout(loadFaqs, 250); });
document.addEventListener('keydown', (e) => { if (e.key === 'Escape') { closeForm(); $('delBg').classList.remove('show'); } });
[$('modalBg'), $('delBg')].forEach((bg) => bg.addEventListener('click', (e) => { if (e.target === bg) bg.classList.remove('show'); }));

(async function init() { await loadCategories(); await Promise.all([loadFaqs(), loadStats()]); })();
