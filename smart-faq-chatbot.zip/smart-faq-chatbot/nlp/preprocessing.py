"""Text preprocessing pipeline: lowercase -> clean -> tokenize -> stopwords -> stem."""
import re
from nltk.stem import PorterStemmer
from nltk.tokenize import wordpunct_tokenize
from sklearn.feature_extraction.text import ENGLISH_STOP_WORDS

try:  # prefer NLTK's stopword list when the corpus is available
    from nltk.corpus import stopwords
    _STOP = set(stopwords.words("english"))
except Exception:  # fall back to scikit-learn's list (no download required)
    _STOP = set(ENGLISH_STOP_WORDS)

# Keep words that carry meaning in FAQ questions even though they are "stopwords".
_STOP -= {"not", "no", "cannot", "free", "how", "why", "what", "where", "when", "who"}
# Question words add noise for matching; drop them again after the keep-list above.
_STOP |= {"how", "what", "why", "where", "when", "who", "do", "does", "can", "could",
          "would", "please", "tell", "me", "want", "need", "know", "get"}

_stemmer = PorterStemmer()

# Phrase/word normalisation so paraphrases map onto FAQ vocabulary.
_PHRASES = [
    (r"money back|get my money|reimburse\w*", "refund"),
    (r"sign ?up|register\w*|make an account|new account|join", "create account"),
    (r"log ?in|sign ?in", "login"),
    (r"take|accepts?", "accept"),
    (r"pay(ing)? with|ways? to pay|how to pay|how do i pay|pay|payment options", "payment methods"),
    (r"unsubscribe|stop (my )?(plan|subscription)|end (my )?(plan|subscription)", "cancel subscription"),
    (r"encrypted|encryption|safe|secure", "protect security"),
    (r"price|pricing|cost|costs", "plans pricing"),
    (r"hacked|stolen|compromised", "hacked"),
    (r"bug|glitch|error|broken|issue|problem", "bug"),
    (r"helpline|help desk|talk to (a )?(human|person|agent)|call you|phone", "contact support"),
    (r"erase|remove my account", "delete account"),
    (r"2fa|mfa|two step|multi factor", "two factor authentication"),
]


def clean_text(text: str) -> str:
    """Lowercase and strip punctuation/special characters."""
    text = text.lower()
    text = re.sub(r"[^a-z0-9\s]", " ", text)
    for pat, rep in _PHRASES:
        text = re.sub(r"\b(?:%s)\b" % pat, rep, text)
    return re.sub(r"\s+", " ", text).strip()


def tokenize(text: str):
    return wordpunct_tokenize(text)


def preprocess(text: str, as_string: bool = True):
    """Run the full pipeline and return stemmed tokens (or a joined string)."""
    tokens = tokenize(clean_text(text))
    tokens = [t for t in tokens if t not in _STOP and len(t) > 1]
    tokens = [_stemmer.stem(t) for t in tokens]
    return " ".join(tokens) if as_string else tokens
